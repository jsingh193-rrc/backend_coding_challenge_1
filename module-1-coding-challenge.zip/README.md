# Backend Group Activity 1

## Members and their roles

### Jashandeep Singh

Set up the project, create endpoints, write logic.

### Jaspreet Kaur

Wrote unit tests for Rating Calculation.

### Karanvir Singh

Wrote unit tests for Player Lookup.
